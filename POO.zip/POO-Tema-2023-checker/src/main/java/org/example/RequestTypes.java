public enum RequestTypes {
    DELETE_ACCOUNT,
    ACTOR_ISSUE,
    MOVIE_ISSUE,
    OTHERS
}
