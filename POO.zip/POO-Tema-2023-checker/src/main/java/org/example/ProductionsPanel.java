import java.awt.*;

public class ProductionsPanel extends Component {
}
