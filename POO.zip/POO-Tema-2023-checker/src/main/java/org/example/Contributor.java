public abstract class Contributor extends Staff {
    // Constructor
    public Contributor(String userInfo, String username) {
        super(userInfo, username);
    }

    // Implementarea metodelor din interfața RequestsManager

    // Alte metode specifice clasei Contributor
}
