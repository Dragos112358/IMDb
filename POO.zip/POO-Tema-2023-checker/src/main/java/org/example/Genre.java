public enum Genre {
        ACTION,
        ADVENTURE,
        COMEDY,
        DRAMA,
        HORROR,
        SF, // Science Fiction
        FANTASY,
        ROMANCE,
        MYSTERY,
        THRILLER,
        CRIME,
        BIOGRAPHY,
        WAR,
        // Puteți adăuga și alte genuri aici după cum este necesar
}
