public enum AccountType2 {
    REGULAR,
    CONTRIBUTOR,
    ADMIN
}
